<?php
define('DB_HOST','localhost');
define('DB_USERNAME','root');
define('DB_PASSWORD','q1w2e3AA');
define('DB_DATABASE','zhenqing_we510');
define('BASE_URL', '/we510/zhenqing/crud/');