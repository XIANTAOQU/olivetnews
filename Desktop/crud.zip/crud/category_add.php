<?php
require_once 'includes/bootstrap.php';


$view = new View(BASE_VIEW_PATH);



$view->render('category/add');