<?php
namespace Helper;

interface ViewHelperInterface{
	public function render();
}